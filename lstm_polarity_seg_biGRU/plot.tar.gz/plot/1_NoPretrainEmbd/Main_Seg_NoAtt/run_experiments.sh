#!/bin/bash

python main_seg_GRU.py
python main_seg_LSTM.py

