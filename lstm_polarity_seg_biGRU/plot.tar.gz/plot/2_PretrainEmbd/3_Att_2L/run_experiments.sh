#!/bin/bash

python main_seg_attention_2_level_GRU.py
python main_seg_attention_2_level_LSTM.py
